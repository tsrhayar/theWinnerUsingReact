exports.userSignUpValidator = (req, res, next) => {
    req.check('name', 'name is required').notEmpty()
    req.check('email', 'email is required').notEmpty().isEmail()
    req.check('password', 'the password is required').notEmpty().isLength({min: 10}).withMessage('password must contain at less 10 character')

    const errors = req.validationErrors()

    if(errors) {
        const arrayError = errors.map(errorList => {
            return errorList.msg
        })
        return res.status(400).json(arrayError)
    }
    next()
}
